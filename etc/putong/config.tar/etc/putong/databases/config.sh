#!/usr/bin/env bash

# Packet Global variables
postgres_host="localhost"
postgres_port="5432"
postgres_user="postgres"
postgres_db=""
postgres_table="putong_sql_patches_applied"
postgres_pass=""
putong_shard_count="64"
